// function setup() {
//   createCanvas(windowWidth, windowHeight);
//   background("#faebdf");
// }

// function draw() {
//   textFont("Georgia");
//   textSize(40);
//   text("your best inspiration", 100, 100);
// }

const phrase =
  "'My father died eleven years ago. I was only four then. I never thought I'd hear from him again, but now we're writing a book together' To Georg Røed, his father is no more than a shadow, a distant memory. But then one day his grandmother discovers some pages stuffed into the lining of an old red pushchair. The pages are a letter to Georg, written just before his father died, and a story, 'The Orange Girl'. But 'The Orange Girl' is no ordinary story - it is a riddle from the past and centres around an incident in his father's youth. One day he boarded a tram and was captivated by a beautiful girl standing in the aisle, clutching a huge paper bag of luscious-looking oranges. Suddenly the tram gave a jolt and he stumbled forward, sending the oranges flying in all directions. The girl simply hopped off the tram leaving Georg's father with arms full of oranges. Now, from beyond the grave, he is asking his son to help him finally solve the puzzle of her identity.";
const words = phrase.split(" ");
let buttons;
let iterator = 0;
let body;
let movement = true;

console.log(words);

function setup() {
  // createCanvas(windowWidth, windowHeight);
  noCanvas();
  body = select("body");
  body.style("background-color", "#83cabc");

  //create button for each word
  words.forEach((word) => {
    createElement("button", word);
  });

  //cdefine the variable for the forEach function
  buttons = selectAll("button");

  // testo è in ordine
  // buttons.forEach((button) => {
  //   button.style("position: relative");
  //   // button.mouseOver(noLoop);
  //   button.mouseOut(loop);
  // });

  //bonus word con opzione che si ferma (ma poi riprende a muoversi in hover)
  // buttons[3].style("color", "red");
  // buttons[3].mouseClicked(function () {
  //   noLoop();
  //   background(255);
  //   mouseOut(noLoop);
  //   buttons.style("position: absolute");
  // });

  buttons[75].style("color", "red");
  buttons[75].mouseClicked(function () {
    buttons.style("position: relative");
    movement = false;
    // button.mouseOver(noLoop);
    buttons.mouseOut(loop);
  });
}

//button to get the words in order
// BonusWord.select('gameChanger')
// BonusWord = elm.addClass("gameChanger");

// // console.log(buttons);
// console.log(phrase[3]);

function draw() {
  if (movement) {
    iterator++;
    buttons.forEach((button, i) => {
      let x = noise((iterator + 60 * i) / 400) * windowWidth;
      let y = noise((iterator - 40 * i) / 400) * windowHeight;
      button.position(x, y);
    });
  }
}

//

//bonus word
